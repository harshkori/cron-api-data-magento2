<?php
namespace Customodule\Topmenu\Cron;
use Magento\Framework\HTTP\Client\Curl;
class TestCurl
{
    
/**
* @var Curl
*/
protected $curl;

    public function __construct
    (
        Curl $curl
    ) 
    {
        $this->curl = $curl;
    }

    public function execute() 
    {
       
        $logger=\Magento\Framework\App\ObjectManager::getInstance()
        ->get('\Mylog\Mylogger\Log\Customlogger');
        $logger->info("Cron execute");
        $URL = 'http://serverracksandcabinets.com.au/index.php/rest/V1/products/RWS-37031-07';
        
        $authorization="Bearer w5bkknuw2oht6pw8gd27ydnmtiovinra";
        
         //set curl options
         $this->curl->setOption(CURLOPT_HEADER, 0);
         
         $this->curl->setOption(CURLOPT_TIMEOUT, 60);
         
         //set curl header
        
        $this->curl->addHeader("Content-Type", "application/json");
        $this->curl->addHeader("Authorization",$authorization);

        
        $this->curl->addCookie("Cookie", "PHPSESSID=c37a26edac14f79c33ccf5b8ad8f3f88'");
        
         //get request with url

         
        $this->curl->get($URL);
        

        
        $response = $this->curl->getBody();

        $result=json_decode($response,true);

        $x=$this->getApiData($result);
        return $x;
    }
    public function getApiData($result)
    {

        echo "<pre>";   
        $dirname = BP."/pub/media/product_import/";
        $images = $dirname.$result['sku'].'.jpg';

        $bootstrap = \Magento\Framework\App\Bootstrap::create(BP, $_SERVER);
        $objectManager = $bootstrap->getObjectManager();
        $state = $objectManager->get('Magento\Framework\App\State');
        $state->setAreaCode('adminhtml');
        $product = $objectManager->create('Magento\Catalog\Model\Product');
        $product->setTypeId($result['type_id']);// product type
        $product->setStatus($result['status']); // 1 = enabled
        $product->setAttributeSetId($result['attribute_set_id']);
        $product->setName($result['name']);
        $product->setSku($result['sku']);
        $product->setPrice($result['price']);
        $product->setTaxClassId(0); // 0 = None
        $product->setCategoryIds(array(2, 3)); // array of category IDs, 2 = Default 
        $product->setDescription($result['custom_attributes'][1]['value']);
        $product->setShortDescription($result['custom_attributes'][6]['value']);
        $product->setWebsiteIds(array(1)); // Default Website ID
        $product->setStoreId(0); // Default store ID
        $product->setVisibility($result['visibility']); // 4 = Catalog & Search
        $product->setMediaGallery(array('images'=>array (), 'values'=>array ()));
        $product->addImageToMediaGallery($images, array ('image', 'small_image', 'thumbnail'), 
        false, false);
        $product->save(); 

        
    }
 } 